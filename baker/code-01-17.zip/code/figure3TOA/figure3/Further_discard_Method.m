function [return_value]=Further_discard_Method(Node_number,Node_Location,measure_sequence,Size_Grid)

Room_Width=Size_Grid;
Room_Length=Size_Grid;
 
 %%Լ������ʽ��Ŀ Node_number-1
 %%%%Ŀ�������point=[x ; y ; W]    %% (2+Node_number-1)*1  

%%%%%%%%%%%%%%%%%%%%���ۺ��� y=C'x  C=[0 ; 0  ]
Num_inequation_constraint=Node_number-1;
Total_number=(Node_number-1)*Node_number./2;

c_tmp=zeros(2,1);
c=[c_tmp;ones(Total_number,1)];
%%%%%%%%%%%% Bound of ��Ľ��� ��0��Size_Grid�� %%%%%%%%%%%% 
lb = zeros(2+Total_number,1);
ub = Size_Grid*ones(2+Total_number,1); 

%%%%%%%%%%   equation constraint Ax=b  %%%%%%%%%% û��
Aequ=[];
bequ=[];
%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 

%%%           A=Function_get_A(Node_Location,measure_sequence);

A_tmp=zeros(Total_number,2);
b=zeros(Total_number,1);
k=1;
for i=1:(length(measure_sequence)-1)
    for j=(i+1):(length(measure_sequence))


m=measure_sequence(i);
n=measure_sequence(j);

x_1=Node_Location(m,1);
y_1=Node_Location(m,2);

x_2=Node_Location(n,1);
y_2=Node_Location(n,2);
A_tmp(k,:)=[2*x_2-2*x_1,2*y_2-2*y_1];
b(k,:)=[x_2^2-x_1^2+y_2^2-y_1^2];
k=k+1;
    end
end
A=zeros(Total_number,2+Total_number);
A=[A_tmp  -eye(Total_number,Total_number)];
%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 

[point,fval,exitflag,output,lambda] = linprog(c,A,b,Aequ,bequ,lb,ub);% without equation constraint,do not work correctly
% k=length(b);
% maxit=10*k;
% tol=0;
% [point,f,it,B] = lin(A,b,c,k,maxit,tol);


if exitflag<0
    count=1;
    for i=Node_number-1:(-1):1
        [begin,final]=Search(i,measure_sequence,Node_number);
         for j=1:length(begin)
          p=point;
m=measure_sequence(begin(j));
n=measure_sequence(final(j));

x_1=Node_Location(m,1);
y_1=Node_Location(m,2);

x_2=Node_Location(n,1);
y_2=Node_Location(n,2);
% A_tmp=zeros(count,2);
% b=zeros(count,1);
B_tmp(count,:)=[2*x_2-2*x_1,2*y_2-2*y_1];
b_new(count,:)=[x_2^2-x_1^2+y_2^2-y_1^2];

B=[B_tmp  -eye(count,count)];

c_tmpnew=zeros(2,1);
c_new=[c_tmpnew;ones(count,1)];
lb = zeros(2+count,1);
ub = zeros(2+count,1);
ub(1:2) = Size_Grid*ones(2,1); 
ub(3:end) = 2*Size_Grid*ones(count,1); 
[point,fval,exitflag,output,lambda] = linprog(c_new,B,b_new,Aequ,bequ,lb,ub);% without equation constraint,do not work correctly
count=count+1;
        if exitflag>0
            p=point;
        end
        if exitflag<0
            point=p;
            count=count-1;
        end
    end
    end
end

estimated_location=[point(1) point(2)];
return_value=estimated_location;
