function [begin,final]=Search(search_length,measure_sequence,N)
N=5;
search_length=3;
count=1;
measure_sequence=[1 3 2 4 5];
for i=1:N-1
    for j=i+1:N
       if (j-i)==search_length
           begin(count)=i;
           final(count)=j;
           count=count+1;
       end
end
end
%measure_sequenc