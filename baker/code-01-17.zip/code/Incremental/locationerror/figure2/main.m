% main function
clc;
clear all  %��� 
close all; %�ر�֮ǰ����

Size_Grid=10;  %�����С����λ��m 
Room_Length=Size_Grid; %���䳤��
Room_Width=Size_Grid;  %�������
RUNS =1000; %%�������
scale=3;        %%%%%%%%%%%%%%%%%%%%%%%%%%%%�ɱ������GM�㷨�Ŀռ���ɢ������

percent  = 0.9;      %���㶨λ���ʱ��ֻȡǰ90%���������10%
KNN=2;  %% Basic Hamming parameter ��Kendall��������K����ȡƽ��

%location_error_range_abs = 0.05;         %%%%%%%%%%%%%%%%%%%%�ڵ�λ����Χ,��λm
measure_error_range_abs = 0.75;       %%%%%%%%%%%%%%%%%%%�ڵ�Ƕ���Χ,��λms  1ms--0.34m   1ms--44.100  
Node_number=16;
measure_data_probability=0.75;

real_statics_run=floor(RUNS*percent);   

anchor_min=0;   %��С�ڵ�λ�����
anchor_max=0.5;  %���
anchor_gap=0.05;   %���
anchors=anchor_min:anchor_gap:anchor_max;  %%%%%%%%%%%%%%%%%%%%%%%%%%�ɱ������ʵ����ʹ�õĽ�����


for runs = 1:RUNS              
disp(['--------------------------------------------------------- ']);
    disp(['runs = ',num2str(runs)]);
	disp(['--------------------------------------------------------- ']);     
    count=1;     
    for Num_Achohor=anchor_min:anchor_gap:anchor_max
        location_error_range_abs =  Num_Achohor;
        disp(['location_error_range_abs = ',num2str(location_error_range_abs)]);
	    disp(['************* ']); 
        Node_Location=fix(Size_Grid*abs((rand(Node_number,2)))); %     
  
		 %�������˵����ʵ��λ�ã�������Ϣ����˵����λ����ʵ�ʽڵ�λ�ü���
		measure_data=zeros(Node_number,1);  
        real_speaker_location=(Size_Grid*abs((rand(1,2)))); 
        speaker_x=real_speaker_location(1,1);
        speaker_y=real_speaker_location(1,2);
		%%%%%
        
         measure_data_tmp=zeros(Node_number,1);  
    	for k=1:Node_number
         measure_data_tmp(k)=sqrt((speaker_x-Node_Location(k,1)).^2+(speaker_y-Node_Location(k,2)).^2);
        end
			
						%%%%�������ĵĵ���ʱ��ms  Time of  arrival 
			measure_TOA=1000*measure_data_tmp./340;  %��λ����ms
            
			measure_TOA_with_error=measure_TOA + measure_error_range_abs*sign(-0.5+rand(size(measure_TOA)));
         %  [m,index_measurement]=sort(measure_TOA); 
         %  index_measurement_true=index_measurement'
                 
           
			[m,index_measurement_error]=sort(measure_TOA_with_error); %������measure_TOA�ϼ���������[-1 1] ����	
         %   index_measurement_error=index_measurement'
           unindex_measurement_error=measure_TOA_with_error;
            
            
        %     Kendall_Dist(index_measurement_true, index_measurement_error)  
	
            Node_Location_with_error=Node_Location + location_error_range_abs*sign(-0.5+rand(size(Node_Location))); 
 
% 		   		 %%%%%%%%%%%���� table_binary, ʵ�ʲ��ԣ������������� %%%%%%%%%%% 
  table_binary=zeros(Room_Width*scale*Room_Width*scale,Node_number+2);		  		 
  table_binary=creat_table(Node_Location_with_error,Room_Width,Room_Length,scale,Node_number);    
 %  table_binary=creat_table(Node_Location,Room_Width,Room_Length,scale,Node_number);    

        %%�����ĸ���λ������ ͳ�ƶ�λ���  	
        
        %����LPSBL
        estimated_location=0;%SBL_Method(index_measurement_error',table_binary, KNN);
		rmse_SBL_tmp(count) = sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %	  
        
        
%         estimated_location=SBL_Method_old(index_measurement_error',table_binary, KNN);
% 		rmse_old_SBL_tmp(count) = sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %	  
      
        
        %estimated_location=SBL_LP_Basic_Method(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
        
        %Relaxed_LPSBL
        estimated_location=SBL_LP_Relax_Method(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
        rmse_SBL_LP_Basic_tmp(count) = sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
        
        
        %ѡ��n*(n-1)/2����
        estimated_location=SBL_LP_Improved_Method1(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
		rmse_SBL_LP_Relax_tmp(count) =sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
        
        
        %����SBL
        estimated_location=Increment_SBL_LP_Method(Node_number,Node_Location_with_error, unindex_measurement_error',Size_Grid);
		rmse_SBL_LP_Increment_tmp(count) =sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
    
        estimated_location=0;%SBL_All_Random_Method(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
		rmse_SBL_Alldiscard_tmp(count) =sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
        
        estimated_location=0;%SBL_Ndiscard_Method(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
		rmse_SBL_N_tmp(count) =sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
        
         count=count+1;    
            
    end  
    rmse_SBL_final_Anchors(runs,:)=rmse_SBL_tmp;
%     rmse_old_SBL_final_Anchors(runs,:)=rmse_old_SBL_tmp;
	rmse_SBL_LP_final_Anchors(runs,:)=rmse_SBL_LP_Basic_tmp;    
  	rmse_SBL_LP_Relax_final_Anchors(runs,:) =  rmse_SBL_LP_Relax_tmp;
    rmse_SBL_LP_Increment_final_Anchors(runs,:) =  rmse_SBL_LP_Increment_tmp;
    rmse_SBL_All_final_Anchors(runs,:) =  rmse_SBL_Alldiscard_tmp;
    rmse_SBL_N_Increment_final_Anchors(runs,:) =  rmse_SBL_N_tmp;
end  

disp(['Saving and Drawing................. ']);
save data.mat  RUNS Size_Grid  anchors   real_statics_run  rmse_SBL_final_Anchors rmse_SBL_LP_final_Anchors rmse_SBL_LP_Relax_final_Anchors rmse_SBL_LP_Increment_final_Anchors  rmse_SBL_All_final_Anchors  rmse_SBL_N_Increment_final_Anchors%rmse_old_SBL_final_Anchors   

clear all;
load data.mat


%%������С��������ȡǰ90%
[A,B]=sort(rmse_SBL_final_Anchors);
rmse_SBL_MC = mean(A(1:real_statics_run,:));


% [A,B]=sort(rmse_old_SBL_final_Anchors);
% rmse_old_SBL_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_LP_final_Anchors);
rmse_SBL_LP_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_LP_Relax_final_Anchors);
rmse_SBL_LP_Relax_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_LP_Increment_final_Anchors);
rmse_SBL_LP_Increment_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_All_final_Anchors);
rmse_SBL_LP_All_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_N_Increment_final_Anchors);
rmse_SBL_LP_N_MC = mean(A(1:real_statics_run,:));
 
figure('Position',[1 1 1200 900])
plot(anchors, rmse_SBL_LP_Relax_MC, 'b>-', 'LineWidth', 2, 'MarkerFaceColor', 'b');
 %plot(anchors, rmse_SBL_MC, 'gs-', 'LineWidth', 2, 'MarkerFaceColor', 'g');
 hold on;
% plot(anchors, rmse_old_SBL_MC, 'ys-', 'LineWidth', 2, 'MarkerFaceColor', 'y');
 plot(anchors, rmse_SBL_LP_MC, 'r^-', 'LineWidth', 2, 'MarkerFaceColor', 'r');
 plot(anchors, rmse_SBL_LP_Increment_MC, 'kd-', 'LineWidth', 2, 'MarkerFaceColor', 'k');
 %plot(anchors, rmse_SBL_LP_All_MC, 'b>-', 'LineWidth', 2, 'MarkerFaceColor', 'b');
 %plot(anchors, rmse_SBL_LP_N_MC, 'r^-', 'LineWidth', 2, 'MarkerFaceColor', 'r');

hold off
legend('\fontsize{18}\bf LPSBL ', '\fontsize{18}\bf LPSBL-Lite','\fontsize{18}\bf Increment LPSBL');

xlabel('\fontsize{23}\bf Node Location Error  (m)');
ylabel('\fontsize{23}\bf Localization Error  (in units)');
title('\fontsize{23}\bf  Localization Error vs. Node Location Error ');
set(gca,'FontSize',18);









