% main function
%%% Modified MyKendall 2017.01.05  Kendall_Dist.m the last rank.


clc;
clear all  %��� 
close all; %�ر�֮ǰ����

Size_Grid=10;  %�����С����λ��m 
Room_Length=Size_Grid; %���䳤��
Room_Width=Size_Grid;  %�������
RUNS = 500; %%�������
scale=4;  %%%%%%%%%%%%%%%%%%%%%%%%%%%%�ɱ������GM�㷨�Ŀռ���ɢ������

percent  = 0.9;      %���㶨λ���ʱ��ֻȡǰ90%���������10%
KNN=3;  %% Basic Hamming parameter ��Kendall��������K����ȡƽ��

 location_error_range_abs = 0.1;         %%%%%%%%%%%%%%%%%%%%�ڵ�λ����Χ,��λm
 measure_error_range_abs = 0.75;            %%%%%%%%%%%%%%%%%%%�ڵ�Ƕ���Χ,��λms  1ms--0.34m   1ms--44.100

%   location_error_range_abs = 0.05;         %%%%%%%%%%%%%%%%%%%%�ڵ�λ����Χ,��λm
%   measure_error_range_abs = 0.1;            %%%%%%%%%%%%%%%%%%%�ڵ�Ƕ���Χ,��λms  1ms--0.34m   1ms--44.100
%Node_number=30;
measure_data_probability=0.75;

real_statics_run=floor(RUNS*percent);   

anchor_min=10;   %��С�ڵ����
anchor_max=30;  %���
anchor_gap=2;   %���
anchors=anchor_min:anchor_gap:anchor_max;  %%%%%%%%%%%%%%%%%%%%%%%%%%�ɱ������ʵ����ʹ�õĽ�����


for runs = 1:RUNS              
disp(['--------------------------------------------------------- ']);
    disp(['runs = ',num2str(runs)]);
	disp(['--------------------------------------------------------- ']);     
    count=1;     
    for Num_Achohor=anchor_min:anchor_gap:anchor_max
        Node_number =  Num_Achohor;
        disp(['Node_number = ',num2str(Node_number)]);
	    disp(['************* ']); 
        Node_Location=fix(Size_Grid*abs((rand(Node_number,2)))); %     
  
		 %�������˵����ʵ��λ�ã�������Ϣ����˵����λ����ʵ�ʽڵ�λ�ü���
		measure_data=zeros(Node_number,1);  
        real_speaker_location=(Size_Grid*abs((rand(1,2)))); 
        speaker_x=real_speaker_location(1,1);
        speaker_y=real_speaker_location(1,2);
		%%%%%
        
         measure_data_tmp=zeros(Node_number,1);  
    	for k=1:Node_number
         measure_data_tmp(k)=sqrt((speaker_x-Node_Location(k,1)).^2+(speaker_y-Node_Location(k,2)).^2);
        end
			
			%%%%�������ĵĵ���ʱ��ms  Time of  arrival 
			measure_TOA=1000*measure_data_tmp./340;  %��λ����ms
            
			measure_TOA_with_error=measure_TOA + measure_error_range_abs*sign(-0.5+rand(size(measure_TOA)));
         %  [m,index_measurement]=sort(measure_TOA); 
         %  index_measurement_true=index_measurement'
                 
           
			[m,index_measurement_error]=sort(measure_TOA_with_error);%������measure_TOA�ϼ���������[-1 1] ����	
            %[m,unindex_measurement_error]=measure_TOA_with_error;
            unindex_measurement_error=measure_TOA_with_error;
                     
        %     Kendall_Dist(index_measurement_true, index_measurement_error)  
	
            Node_Location_with_error=Node_Location + location_error_range_abs*sign(-0.5+rand(size(Node_Location))); 
 
% 		   		 %%%%%%%%%%%���� table_binary, ʵ�ʲ��ԣ������������� %%%%%%%%%%% 
  table_binary=zeros(Room_Width*scale*Room_Width*scale,Node_number+2);		  		 
  table_binary=creat_table(Node_Location_with_error,Room_Width,Room_Length,scale,Node_number);    
 %  table_binary=creat_table(Node_Location,Room_Width,Room_Length,scale,Node_number);    

          %%�����ĸ���λ������ ͳ�ƶ�λ���  	
        
        %�������SBL
          estimated_location=0;%SBL_Method(index_measurement_error',table_binary, KNN);
	rmse_SBL_tmp(count) = sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %	  
      
     
        %Relaxed_LPSBL
        estimated_location=SBL_LP_Relax_Method(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
        rmse_SBL_LP_Basic_tmp(count) = sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
        
        
        %ѡ��n*(n-1)/2����
        estimated_location=SBL_LP_Improved_Method1(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
		rmse_SBL_LP_Relax_tmp(count) =sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
        
        
        %����SBL
        estimated_location=Increment_SBL_LP_Method(Node_number,Node_Location_with_error, unindex_measurement_error',Size_Grid);
		rmse_SBL_LP_Increment_tmp(count) =sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
        
        %all ����
        estimated_location=0;%SBL_All_Random_Method(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
		rmse_SBL_All_Random_tmp(count) =sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   
        
        %��n-1������
        %all ����
        estimated_location=0;%SBL_Ndiscard_Method(Node_number,Node_Location_with_error,index_measurement_error',Size_Grid);
		rmse_SBL_N_tmp(count) =sqrt( sum((real_speaker_location(:)-estimated_location(:)).^2) );  %   

      % estimated_location_1=SBL_Robust_Method(Node_number,index_measurement_error,measure_data_probability,Node_Location_with_error,Size_Grid,scale);
      %  rmse_SBL_Robust_tmp(count) = sqrt( sum((real_speaker_location(:)-estimated_location_1(:)).^2) );  %  
     %  rmse_SBL_Robust_tmp(count)=0;
         count=count+1;    
            
    end  
    rmse_SBL_final_Anchors(runs,:)=rmse_SBL_tmp;
	rmse_SBL_LP_final_Anchors(runs,:)=rmse_SBL_LP_Basic_tmp;    
  	rmse_SBL_LP_Relax_final_Anchors(runs,:) =  rmse_SBL_LP_Relax_tmp;
    rmse_SBL_LP_Increment_final_Anchors(runs,:) =  rmse_SBL_LP_Increment_tmp;
    rmse_SBL_All_Random_Anchors(runs,:) = rmse_SBL_All_Random_tmp;
    rmse_SBL_N_Anchors(runs,:)=rmse_SBL_N_tmp;
end  

disp(['Saving and Drawing................. ']);
save data.mat  RUNS Size_Grid  anchors   real_statics_run  rmse_SBL_final_Anchors rmse_SBL_LP_final_Anchors rmse_SBL_LP_Relax_final_Anchors rmse_SBL_LP_Increment_final_Anchors  rmse_SBL_All_Random_Anchors  rmse_SBL_N_Anchors

clear all;
load data.mat


%%������С��������ȡǰ90%
[A,B]=sort(rmse_SBL_final_Anchors);
rmse_SBL_MC = mean(A(1:real_statics_run,:));


[A,B]=sort(rmse_SBL_LP_final_Anchors);
rmse_SBL_LP_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_LP_Relax_final_Anchors);
rmse_SBL_LP_Relax_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_LP_Increment_final_Anchors);
rmse_SBL_LP_Increment_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_All_Random_Anchors);
rmse_SBL_LP_All_Random_MC = mean(A(1:real_statics_run,:));

[A,B]=sort(rmse_SBL_N_Anchors);
rmse_SBL_N_Random_MC = mean(A(1:real_statics_run,:));
 
figure('Position',[1 1 1200 900])
plot(anchors, rmse_SBL_LP_Relax_MC, 'b>-', 'LineWidth', 2, 'MarkerFaceColor', 'b');
 hold on;
 
 plot(anchors, rmse_SBL_LP_MC, 'r^-', 'LineWidth', 2, 'MarkerFaceColor', 'r');
 plot(anchors, rmse_SBL_LP_Increment_MC, 'kd-', 'LineWidth', 2, 'MarkerFaceColor', 'k');
 %plot(anchors, rmse_SBL_LP_All_Random_MC, 'yd-', 'LineWidth', 2, 'MarkerFaceColor', 'y');
%plot(anchors, rmse_SBL_N_Random_MC, 'cd-', 'LineWidth', 2, 'MarkerFaceColor', 'c');
hold off
% legend('\fontsize{12}\bf Basic SBL','\fontsize{12}\bf Relax LP SBL ', '\fontsize{12}\bf Whole Point LPSBL','\fontsize{12}\bf Increment LP SBL');
legend('\fontsize{16}\bf LPSBL ', '\fontsize{16}\bf LPSBL-Lite','\fontsize{16}\bf Incremental LPSBL')%,'\fontsize{12}\bf Increment LP SBL');

xlabel('\fontsize{20}\bf Number of Nodes');
ylabel('\fontsize{20}\bf Localization Error  (in units)');
title('\fontsize{20}\bf  Localization Error vs. Number of Nodes');
set(gca,'FontSize',16);


% figure('Position',[1 1 1200 900])
% [f1,x1] = ecdf(rmse_SBL_MC);
% plot(x1,f1,'gs-', 'LineWidth', 2, 'MarkerFaceColor', 'g');
% hold on
% [f2,x2] = ecdf(rmse_SBL_LP_MC);
% plot(x2,f2, 'r^-', 'LineWidth', 2, 'MarkerFaceColor', 'r');
% [f3,x3] = ecdf(rmse_SBL_LP_Relax_MC);
% plot(x3,f3, 'b>-', 'LineWidth', 2, 'MarkerFaceColor', 'b');
% [f4,x4] = ecdf(rmse_SBL_LP_Increment_MC);
% plot(x4,f4,  'kd-', 'LineWidth', 2, 'MarkerFaceColor', 'k');
% hold off
% legend('\fontsize{12}\bf Basic SBL','\fontsize{12}\bf Relax LP SBL', '\fontsize{12}\bf ALL LPSBL','\fontsize{12}\bf Incremental LP');
% xlabel('\fontsize{12}\bf Localization Error(in units)');
% ylabel('\fontsize{12}\bf CDF');
% title('\fontsize{12}\bf  Localization Error vs. CDF');









