function [return_value]=SBL_Ndiscard_Method(Node_number,Node_Location,measure_sequence,Size_Grid)

Room_Width=Size_Grid;
Room_Length=Size_Grid;
 
 %%Լ������ʽ��Ŀ Node_number-1
 %%%%Ŀ�������point=[x ; y ; W]    %% (2+Node_number-1)*1  

%%%%%%%%%%%%%%%%%%%%���ۺ��� y=C'x  C=[0 ; 0  ]
%Num_inequation_constraint=Node_number-1;
c_tmp=zeros(2,1);

% c=[c_tmp;ones(Num_inequation_constraint,1)];
%%%%%%%%%%%% Bound of ��Ľ��� ��0��Size_Grid�� %%%%%%%%%%%% 
% lb = zeros(2+Num_inequation_constraint,1);
% ub = Size_Grid*ones(2+Num_inequation_constraint,1); 

%%%%%%%%%%   equation constraint Ax=b  %%%%%%%%%% û��
Aequ=[];
bequ=[];
%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 

%%%           A=Function_get_A(Node_Location,measure_sequence);

% A_tmp=zeros(Node_number-1,2);
% b=zeros(Node_number-1,1);

count=1;
for i=1:(length(measure_sequence)-1)
   if i>1
    p=point;
   end
m=measure_sequence(i);
n=measure_sequence(i+1);

x_1=Node_Location(m,1);
y_1=Node_Location(m,2);

x_2=Node_Location(n,1);
y_2=Node_Location(n,2);
A_tmp(count,:)=[2*x_2-2*x_1,2*y_2-2*y_1];
b(count,:)=[x_2^2-x_1^2+y_2^2-y_1^2];
c=[c_tmp;ones(count,1)];
lb = zeros(2+count,1);
ub = zeros(2+count,1);
ub(1:2) = Size_Grid*ones(2,1); 
ub(3:end) = 2*Size_Grid*ones(count,1); 
A=[A_tmp  -eye(count,count)];
[point,fval,exitflag,output,lambda] = linprog(c,A,b,Aequ,bequ,lb,ub);
count=count+1;
if exitflag>0
            p=point;
end
if exitflag<0
    point=p;
    count=count-1;
end
    end   
%A=zeros(Node_number-1,2+Num_inequation_constraint);
%A=[A_tmp  -eye(Num_inequation_constraint,Num_inequation_constraint)];
%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 

%[point,fval,exitflag,output,lambda] = linprog(c,A,b,Aequ,bequ,lb,ub);% without equation constraint,do not work correctly
% k=length(b);
% maxit=10*k;
% tol=0;
% [point,f,it,B] = lin(A,b,c,k,maxit,tol);

estimated_location=[point(1) point(2)];

return_value=estimated_location;