function [return_value]=SBL_LP_Basic_Method(Node_number,Node_Location,measure_sequence,Size_Grid)

Room_Width=Size_Grid;
Room_Length=Size_Grid;
 
 %%%%Ŀ�������point=[x ;  y]    %% 2*1  

%%%%%%%%%%%%%%%%%%%%���ۺ��� y=C'x  C=[0 ; 0 ]

c=zeros(2,1);

%%%%%%%%%%%% Bound of ��Ľ��� ��0��Size_Grid�� %%%%%%%%%%%% 
lb = zeros(2,1);
ub = Size_Grid*ones(2,1); 

%%%%%%%%%%   equation constraint Ax=b  %%%%%%%%%% û��
Aequ=[];
bequ=[];
%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 

%%%           A=Function_get_A(Node_Location,measure_sequence);

A=zeros(Node_number-1,2);
b=zeros(Node_number-1,1);
for i=1:(length(measure_sequence)-1)


m=measure_sequence(i);
n=measure_sequence(i+1);

x_1=Node_Location(m,1);
y_1=Node_Location(m,2);

x_2=Node_Location(n,1);
y_2=Node_Location(n,2);
A(i,:)=[2*x_2-2*x_1,2*y_2-2*y_1];
b(i,:)=[x_2^2-x_1^2+y_2^2-y_1^2];

end


%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 

[point,fval,exitflag,output,lambda] = linprog(c,A,b,Aequ,bequ,lb,ub);% without equation constraint,do not work correctly


estimated_location=[point(1) point(2)];
return_value=estimated_location;

