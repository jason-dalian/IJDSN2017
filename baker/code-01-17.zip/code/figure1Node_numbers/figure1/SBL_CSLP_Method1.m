%Լ��ѡ�񷽷�
function [return_value]=SBL_CSLP_Method1(Node_number,Node_Location,measure_sequence,Size_Grid)

Iter=10;   %��������
Num=10;     %ѡ���ߵ�����
Room_Width=Size_Grid;
Room_Length=Size_Grid;
Total_number=(Node_number-1)*Node_number./2;
 
 %%Լ������ʽ��Ŀ Node_number-1
 %%%%Ŀ�������point=[x ; y ; W]    %% (2+Node_number-1)*1  

%%%%%%%%%%%%%%%%%%%%���ۺ��� y=C'x  C=[0 ; 0  ]
Num_inequation_constraint=Num;
c_tmp=zeros(2,1);

c=[c_tmp;ones(Num,1)];
%%%%%%%%%%%% Bound of ��Ľ��� ��0��Size_Grid�� %%%%%%%%%%%% 
lb = zeros(2+Num,1);
ub = Size_Grid*ones(2+Num,1); 

%%%%%%%%%%   equation constraint Ax=b  %%%%%%%%%% û��
Aequ=[];
bequ=[];
%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 

%%%           A=Function_get_A(Node_Location,measure_sequence);

%A_tmp=zeros(Num,2);
%b=zeros(Num,1);
k=1;
for i=1:(length(measure_sequence)-1)
    for j=(i+1):(length(measure_sequence))

m=measure_sequence(i);
n=measure_sequence(j);

x_1=Node_Location(m,1);
y_1=Node_Location(m,2);

x_2=Node_Location(n,1);
y_2=Node_Location(n,2);

Total(k,1)=2*x_2-2*x_1;
Total(k,2)=2*y_2-2*y_1;
Total(k,3)=x_2^2-x_1^2+y_2^2-y_1^2;
Total(k,4)=(x_1-x_2)/(y_2-y_1);  %�д��ߵ�б��
Total(k,5)=(x_1+x_2)/2;
Total(k,6)=(y_1+y_2)/2;
% A_tmp(k,:)=[2*x_2-2*x_1,2*y_2-2*y_1];
% b(k,:)=[x_2^2-x_1^2+y_2^2-y_1^2];
k=k+1;
    end
end

for i=1:Num
    j=randint(1,1,[1,Total_number]);
%     A_tmp(i,1)=Total(j,1);
%     A_tmp(i,2)=Total(j,2);
%     b(i,1)=Total(j,3);
%     k(i,1)=Total(j,4);
%     x(i,1)=Total(j,5);
%     y(i,1)=Totak(j,6);
     A_tmp(i,:)=Total(j,:);
     b(i,:)=Total(j,3);
end
%A=zeros(Num,2+Num);
B_tmp=A_tmp(:,1:2);
A=[B_tmp  -eye(Num,Num)];
%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 
[point,fval,exitflag,output,lambda] = linprog(c,A,b,Aequ,bequ,lb,ub);% without equation constraint,do not work correctly
for i=1:Num
    d(1,i)=abs(point(2)-A(i,4)*(point(1)-A(i,5))-A(i,6))/sqrt(1+A(i,4)^2);
end
[m,index]=sort(d);


for count=1:Iter
    temp1=A_tmp(index(1),:);
    temp2=A_tmp(index(2),:);
    A_tmp(1,:)=temp1;
    A_tmp(2,:)=temp2;
    b(1,:)=A_tmp(index(1),3);
    b(2,:)=A_tmp(index(2),3);
    for i=3:Num
        j=randint(1,1,[1,Total_number]);
        A_tmp(i,:)=Total(j,:);
        b(i,:)=Total(j,3);
    end
    B_tmp=A_tmp(:,1:2);
    A=[B_tmp  -eye(Num,Num)];
%%%%%%%%%%   inequation constraint Ax<b  %%%%%%%%%% 
    [point,fval,exitflag,output,lambda] = linprog(c,A,b,Aequ,bequ,lb,ub);% without equation constraint,do not work correctly
    for i=1:Num
    d(1,i)=abs(point(2)-A(i,4)*(point(1)-A(i,5))-A(i,6))/sqrt(1+A(i,4)^2);
    end
    [m,index]=sort(d);
end

estimated_location=[point(1) point(2)];
return_value=estimated_location;

